package api.paths.generalPaths;

public class GeneralPaths {

    public static final String WEBBANK = "/webbank";
    public static final String ACCESS_TOKEN = "/sso/oauth2/access_token";
}
