package api.paths.product;

public class CardPaths {

    public static final String CARD = "/api/card/product/card/";
}
