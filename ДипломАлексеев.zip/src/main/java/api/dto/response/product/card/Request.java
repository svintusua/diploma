
package api.dto.response.product.card;


public class Request {


}
