package api.paths.product;

public class AccountPaths {
    public static final String ACCUMULATION_LIST = "/api/account/product/account/accumulation/list/";
}
