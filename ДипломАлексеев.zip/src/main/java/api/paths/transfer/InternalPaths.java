package api.paths.transfer;

public class InternalPaths {

    public static final String ACCOUNT_TO_CARD = "/api/money-transfer/money/transfer/internal/client/account/tocard/";
}
