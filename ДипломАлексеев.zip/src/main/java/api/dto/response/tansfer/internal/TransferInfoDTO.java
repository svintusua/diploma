
package api.dto.response.tansfer.internal;


public class TransferInfoDTO {

    private Boolean success;
    private Data data;

    public Boolean getSuccess() {
        return success;
    }

    public Data getData() {
        return data;
    }
}
