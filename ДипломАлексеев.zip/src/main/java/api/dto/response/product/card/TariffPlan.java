package api.dto.response.product.card;

public class TariffPlan {

    private String name;
    private String tariffInfoURL;

    public String getName() {
        return name;
    }

    public String getTariffInfoURL() {
        return tariffInfoURL;
    }
}
